<?php
/**
 * The template used for displaying credits
 *
 * @package Zubin
 */
?>

<?php
/**
 * zubin_credits hook
 * @hooked zubin_footer_content - 10
 */
do_action( 'zubin_credits' );
